// *Variables*
// Declare a variable, reassign it to your favorite food, and alert the value

//Declare a variable, assign it a string, alert the second character in the string (Use your google-fu and the MDN)


// *Functions*
// Create a function that takes in 3 numbers. Divide the first two numbers and multiply the last. Alert the product. Call the function.


// Create a function that takes in 1 number. Console log the cube root of the number. Call the function.


// *Conditionals*
//Create a function that takes in a month. If it is a summer month alert "YAY". If another other month, alert "Booo"


//*Loops*
//Create a function that takes in a number. Console log every number from 1 to that number while skipping multiples of 5.
