//Write your pseduo code first! 
