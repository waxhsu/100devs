const andi = document.querySelector('#andi')
const claire = document.querySelector('#claire')
const sharleen = document.querySelector('#sharleen')

document.querySelector('#andiNext').addEventListener('click', /*INSERTCODE*/)
document.querySelector('#claireNext').addEventListener('click', /*INSERTCODE*/)
document.querySelector('#sharleenNext').addEventListener('click', /*INSERTCODE*/)

function andiNext(){
	claire.classList.add(/*INSERTCODE*/)
	sharleen.classList.add(/*INSERTCODE*/)
	andi.classList.toggle(/*INSERTCODE*/)
}

function claireNext(){
	/*INSERTCODE*/.classList.add(/*INSERTCODE*/)
	/*INSERTCODE*/.classList.add(/*INSERTCODE*/)
	/*INSERTCODE*/.classList.toggle(/*INSERTCODE*/)
}

function sharleenNext(){
	/*INSERTCODE*/.classList.add(/*INSERTCODE*/)
	/*INSERTCODE*/.classList.add(/*INSERTCODE*/)
	/*INSERTCODE*/.classList.toggle(/*INSERTCODE*/)
}
